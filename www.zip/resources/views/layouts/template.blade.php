@extends('layouts.app')

{{-- HTML Title --}}
@section('html-title')

@endsection

{{-- Top Css --}}
@section('css-top')

@endsection

{{-- Bottom Css --}}
@section('css-bot')

@endsection

{{-- Page Title --}}
@section('page-title')

@endsection

{{-- Breadcrumb --}}
@section('breadcrumb')

@endsection

{{-- Main Content --}}
@section('main-content')

@endsection

{{-- Top Page Js --}}
@section('js-top')

@endsection

{{-- Bottom Js Script --}}
@section('js-bot')

@endsection