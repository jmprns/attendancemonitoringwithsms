<?php $__env->startSection('html-title'); ?>
Dashboard
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css-top'); ?>
<!-- DataTables -->
<link href="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('vendor/datatables/buttons.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css-bot'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
Dashboard
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>
<li class="active">
	Dashboard
</li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
<div class="row">

                            <div class="col-lg-4 col-md-6">
                                <div class="card-box widget-box-three">
                                    <div class="bg-icon pull-left">
                                        <i class="ti-user"></i>
                                    </div>
                                    <div class="text-right">
                                        <p class="text-success m-t-5 text-uppercase font-600 font-secondary">Students</p>
                                        <h2 class="m-b-10"><span data-plugin="counterup"><?php echo e($count['student']); ?></span></h2>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-6">
                                <div class="card-box widget-box-three">
                                    <div class="bg-icon pull-left">
                                        <i class="ti-flag"></i>
                                    </div>
                                    <div class="text-right">
                                        <p class="text-success m-t-5 text-uppercase font-600 font-secondary">Events</p>
                                        <h2 class="m-b-10"><span data-plugin="counterup"><?php echo e($count['events']); ?></span></h2>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-6">
                                <div class="card-box widget-box-three">
                                    <div class="bg-icon pull-left">
                                        <i class="ti-time"></i>
                                    </div>
                                    <div class="text-right">
                                        <p class="text-success m-t-5 text-uppercase font-600 font-secondary"><?php echo e(strtoupper(date('l', time()))); ?></p>
                                        <h2 class="m-b-10"><?php echo e(date('h:i A', time())); ?></h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card-box table-responsive">
                                    <h4 class="m-t-0 header-title"><b>Attendance today.</b></h4>
                                    <table id="datatable" class="table table-striped table-bordered">
                                        <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Name</th>
                                            <th>Department</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $att): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(date('Y-m-d h:i:s A', $att->timestamp)); ?></td>
                                            <td><?php echo e(@$att->student->lname); ?>, <?php echo e(@$att->student->fname); ?> <?php echo e(@$att->student->mname); ?>.</td>
                                            <td><?php echo e(@$att->student->year->department->name); ?> - <?php echo e(@$att->student->year->name); ?></td>
                                            <td><?php if($att->action == 0): ?> TIME IN <?php else: ?> TIME OUT <?php endif; ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js-top'); ?>
<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/datatables/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/buttons.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.fixedHeader.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.keyTable.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/responsive.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.scroller.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.colVis.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.fixedColumns.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js-bot'); ?>
<script type="text/javascript">
    $(document).ready(function () {
        $('#datatable').DataTable({
            dom: "Bfrtip",
            buttons: [{
                extend: "copy",
                className: "btn-sm"
            }, {
                extend: "csv",
                className: "btn-sm"
            }, {
                extend: "excel",
                className: "btn-sm"
            }, {
                extend: "pdf",
                className: "btn-sm"
            }, {
                extend: "print",
                className: "btn-sm"
            }],
            responsive: !0
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>