<?php $__env->startSection('html-title'); ?>
Attendance
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css-top'); ?>
<!-- DataTables -->
<link href="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('vendor/datatables/buttons.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css-bot'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
Event Attendance <small>(<?php echo e($event->name); ?>)</small>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>
<a href="/scan/event/<?php echo e($event->id); ?>" target="_new" class="btn btn-default">Open Scanning Page</a>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
<table id="datatable" class="table table-striped table-bordered">
    <thead>
    <tr>
        <th>Date (yyyy-mm-dd)</th>
        <th>Name</th>
        <th>Department - Year</th>
        <th>Action</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $att): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(date('Y-m-d h:i A', $att->timestamp)); ?></td>
        <td><?php echo e($att->student->lname); ?>, <?php echo e($att->student->fname); ?> <?php echo e($att->student->mname); ?>.</td>
        <td><?php echo e($att->student->year->department->name); ?> - <?php echo e($att->student->year->name); ?></td>
        <td><?php if($att->action == 0): ?> TIME IN <?php else: ?> TIME OUT <?php endif; ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js-top'); ?>
<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js-bot'); ?>
<script type="text/javascript">
    $('#datatable').dataTable({
        "order": [[ 0, "desc" ]]
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>