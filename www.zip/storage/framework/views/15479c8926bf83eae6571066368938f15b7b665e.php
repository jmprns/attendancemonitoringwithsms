<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="_token" content="<?php echo e(csrf_token()); ?>">

        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('media/favicon.ico')); ?>">
        <!-- App title -->
        <title>Attendance Monitoring - Login</title>

        
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/swal/sweet-alert.css')); ?>">

        <!-- App css -->
        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/core.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/components.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/icons.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/pages.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/menu.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- HTML5 Shiv and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js')}}"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js')}}"></script>
        <![endif]-->


    </head>


    <body class="bg-transparent">

        <!-- HOME -->
        <section>
            <div id="login-body" class="container-alt">
                <div class="row">
                    <div class="col-sm-12">

                        <div class="wrapper-page">
                            <div class="clearfix"></div>
                            <div class="m-t-40 account-pages">
                                <div class="text-center account-logo-box">
                                    <h4 class="text-uppercase font-bold m-b-0" style="color: white;"><i class="mdi mdi-star-circle"></i> LOG IN <i class="mdi mdi-star-circle"></i></h4>
                                    <h3 class="text-uppercase font-bold m-b-0" style="color: white;">Attendance Monitoring</h3>
                                </div>
                                <div class="account-content">
                                    <form method="POST" class="form-horizontal" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group ">
                                            <div class="col-xs-12">
                                                <input class="form-control" id="email" type="email" placeholder="Email Address" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <div class="col-xs-12">
                                                <input class="form-control" id="password" type="password" name="password" placeholder="Password" required>
                                            </div>
                                        </div>

                                        <div class="form-group ">
                                            <div class="col-xs-12">
                                                <div class="checkbox checkbox-success">
                                                    <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                                    <label for="checkbox-signup">
                                                        Remember me
                                                    </label>
                                                </div>

                                            </div>
                                        </div>

                                        <div class="form-group account-btn text-center m-t-10">
                                            <div class="col-xs-12">
                                                <button class="btn w-md btn-bordered btn-danger waves-effect waves-light" type="submit">Log In</button>
                                            </div>
                                        </div>

                                    </form>

                                    <div class="clearfix"></div>

                                </div>
                            </div>
                            <!-- end card-box-->


                           

                        </div>
                        <!-- end wrapper -->

                    </div>
                </div>
            </div>
          </section>
          <!-- END HOME -->

        <script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/detect.js')); ?>"></script>
        <script src="<?php echo e(asset('js/fastclick.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.blockUI.js')); ?>"></script>
        <script src="<?php echo e(asset('js/waves.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.slimscroll.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.scrollTo.min.js')); ?>"></script>
        <script src="<?php echo e(asset('vendor/switchery/switchery.min.js')); ?>"></script>

        <!-- App js -->
        <script src="<?php echo e(asset('js/jquery.core.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.app.js')); ?>"></script>

    </body>
</html>