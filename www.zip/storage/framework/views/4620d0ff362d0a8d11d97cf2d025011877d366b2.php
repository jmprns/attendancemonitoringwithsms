<?php $__env->startSection('html-title'); ?>
Student List
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css-top'); ?>
<!-- DataTables -->
<link href="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('vendor/datatables/buttons.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css-bot'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
Student List
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>
<li class="active">
	List
</li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
<div class="row">
    <div class="col-sm-12">
        <div class="card-box table-responsive">
            <h4 class="m-t-0 header-title"><b>Default Example</b></h4>
            <p class="text-muted font-13 m-b-30">
                DataTables has most features enabled by default, so all you need to do to use it with
                your own tables is to call the construction function: <code>$().DataTable();</code>.
            </p>

            <table id="datatable" class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th width="8%"></th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>RFID Tag</th>
                    <th>Department - Year</th>
                    <th>Phone Number</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php ($x = 1); ?>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align="center"><?php echo e($x++); ?></td>
                    <td align="center">
                        <a href="javascript:void(0)" onclick="show_image('<?php echo e($student->image); ?>')">
                            <img src="<?php echo e(asset('images/students')); ?>/<?php echo e($student->image); ?>" alt="user" class="thumb-sm" />
                        </a>
                    </td>
                    <td><?php echo e($student->lname); ?>, <?php echo e($student->fname); ?> <?php echo e($student->mname); ?>.</td>
                    <td><?php echo e($student->rfid); ?></td>
                    <td><?php echo e($student->year->department->name); ?> - <?php echo e($student->year->name); ?></td>
                    <td><?php echo e($student->number); ?></td>
                    <td align="center">
                        <a href="/student/edit/<?php echo e($student->id); ?>" class="table-action-btn h3"><i class="mdi mdi-pencil-box-outline text-success"></i></a>
                        <a href="#" class="table-action-btn h3"><i class="mdi mdi-close-box-outline text-danger"></i></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js-top'); ?>
<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js-bot'); ?>
<script type="text/javascript">
    $(document).ready(function () {
        $('#datatable').dataTable();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>