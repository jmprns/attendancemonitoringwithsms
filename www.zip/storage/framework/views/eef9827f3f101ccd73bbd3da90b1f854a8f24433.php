<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="_token" content="<?php echo e(csrf_token()); ?>">

        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>">
        <!-- App title -->
        <title>Attendance Monitoring - <?php echo $__env->yieldContent('html-title'); ?></title>

        <?php $__env->startSection('css-top'); ?>
        <?php echo $__env->yieldSection(); ?>

        <!-- App css -->
        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/core.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/components.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/icons.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/pages.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/menu.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('vendor/whirl/whirl.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('vendor/toastr/toastr.min.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- HTML5 Shiv and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->

        <?php $__env->startSection('css-bot'); ?>
        <?php echo $__env->yieldSection(); ?>
        <script src="<?php echo e(asset('js/modernizr.min.js')); ?>"></script>

    </head>


    <body class="fixed-left">

        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
            <div class="topbar">

                <!-- LOGO -->
                <div class="topbar-left">
                    <a href="javascript:void(0)" class="logo"><span>WUP<span>AURORA</span></span><i class="mdi mdi-layers"></i></a>
                    <!-- Image logo -->
                    <!--<a href="index.html" class="logo">-->
                        <!--<span>-->
                            <!--<img src="assets/images/logo.png" alt="" height="30">-->
                        <!--</span>-->
                        <!--<i>-->
                            <!--<img src="assets/images/logo_sm.png" alt="" height="28">-->
                        <!--</i>-->
                    <!--</a>-->
                </div>

                <!-- Button mobile view to collapse sidebar menu -->
                <div class="navbar navbar-default" role="navigation">
                    <div class="container">

                        <!-- Navbar-left -->
                        <ul class="nav navbar-nav navbar-left">
                            <li>
                                <button class="button-menu-mobile open-left waves-effect">
                                    <i class="mdi mdi-menu"></i>
                                </button>
                            </li>
                        </ul>

                        <!-- Right(Notification) -->
                        <ul class="nav navbar-nav navbar-right">
                            <li>
                                <a class="right-menu-item" href="#" alt="Toggle full screen">
                                    <i class="mdi mdi-fullscreen"></i>
                                </a>
                            </li>
                            <li>
                                <a class="right-menu-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                                    <i class="mdi mdi-logout-variant"></i>
                                </a>
                            </li>
                        </ul> <!-- end navbar-right -->

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>

                    </div><!-- end container -->
                </div><!-- end navbar -->
            </div>
            <!-- Top Bar End -->


            <!-- ========== Left Sidebar Start ========== -->
            <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <ul>
                            <li class="menu-title">Navigation</li>

                            <li>
                                <a href="/dashboard" class="waves-effect"><i class="mdi mdi-view-dashboard"></i><span> Dashboard </span></a>
                            </li>

                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-calendar-clock"></i><span> Attendance </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="/attendance/events">Events</a></li>
                                    <li><a href="/attendance/">Regular</a></li>
                                </ul>
                            </li>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-account-multiple"></i><span> Students </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="/student/register">Register</a></li>
                                    <li><a href="/student">Update</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="/settings" class="waves-effect"><i class="mdi mdi-settings"></i><span> Settings </span></a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();" class="waves-effect"><i class="mdi mdi-logout-variant"></i><span> Logout </span></a>
                            </li>


                        </ul>
                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                    <div class="help-box">
                        <h5 class="text-muted m-t-0">For Help ?</h5>
                        <p class=""><span class="text-custom">Email:</span> <br/> support@support.com</p>
                        <p class="m-b-0"><span class="text-custom">Call:</span> <br/> (+123) 123 456 789</p>
                    </div>

                </div>
                <!-- Sidebar -left -->

            </div>
            <!-- Left Sidebar End -->



            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="page-title-box">
                                    <h5 class="page-title"><?php echo $__env->yieldContent('page-title'); ?></h5>
                                    <ol class="breadcrumb p-0 m-0">
                                        <?php $__env->startSection('breadcrumb'); ?>
                                        <?php echo $__env->yieldSection(); ?>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->

                        <?php $__env->startSection('main-content'); ?>
                        <?php echo $__env->yieldSection(); ?>


                    </div> <!-- container -->

                </div> <!-- content -->

                <footer class="footer text-right">
                    2019 © Attendance Monitoring.
                </footer>

            </div>


            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->



        <script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/detect.js')); ?>"></script>
        <script src="<?php echo e(asset('js/fastclick.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.blockUI.js')); ?>"></script>
        <script src="<?php echo e(asset('js/waves.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.slimscroll.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.scrollTo.min.js')); ?>"></script>
        <script src="<?php echo e(asset('vendor/toastr/toastr.min.js')); ?>"></script>

        <?php $__env->startSection('js-top'); ?>
        <?php echo $__env->yieldSection(); ?>

        <!-- App js -->
        <script src="<?php echo e(asset('js/jquery.core.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.app.js')); ?>"></script>

        <?php $__env->startSection('js-bot'); ?>
        <?php echo $__env->yieldSection(); ?>

    </body>
</html>